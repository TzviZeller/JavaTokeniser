public interface Identifiers
{
	public boolean isValidIdentifier(String s);
}
