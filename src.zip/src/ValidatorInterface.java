public interface ValidatorInterface 
{
    
    public void validate();
    public boolean isValid();
    public String[] getErrors();
    
}