public interface Comments {
    
    public boolean isComment(String str);
    
}