public class JavaComments implements Comments {
 
    public boolean isComment(String s)
    {
        return (s.charAt(0)=='/') && (s.charAt(1)=='/');
    }
    
}