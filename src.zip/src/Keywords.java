public interface Keywords
{
	public boolean isKeyword(String s);
}
