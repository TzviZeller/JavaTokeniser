
public class ProgramValidator
{
    private TokenizedLines tlines;
    private ValidatorInterface[] validators;
    private String[] all_errors;

    public ProgramValidator(TokenizedLines tlines, ValidatorInterface[] validators)
    {
        this.tlines = tlines;
        this.validators = validators;
        all_errors = new String[50];
    }

    public void start()
    {
        for (ValidatorInterface v : validators)
        {
            v.validate();
            
            if(!v.isValid())
                addErrors(v.getErrors());
        }
    }

    public String[] getErrors()
    {
        return all_errors;
    }

    private void addErrors(String[] new_errors)
    {
        // add these new errors to end of String array all_errors
    }
    
}