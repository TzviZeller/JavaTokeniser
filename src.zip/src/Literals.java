public interface Literals
{
	public boolean isLiteral(String s);
}
