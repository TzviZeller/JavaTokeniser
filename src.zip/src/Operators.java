public interface Operators
{
	public boolean isOperator(String s);
}
