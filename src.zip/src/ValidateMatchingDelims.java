public class ValidateMatchingDelims implements ValidatorInterface
{
    
    private TokenizedLines tlines;
    private String[] errors;

    public ValidateMatchingDelims(TokenizedLines tlines)
    {
        this.tlines = tlines;
    }

    public boolean isValid()
    {
		return false;
        // code to check if any mismatched delimiters
        // when an error found, added to next available row of String array errors
        // use of stack for checking if (paired) delimiters match
    }

	@Override
	public void validate() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String[] getErrors() {
		// TODO Auto-generated method stub
		return null;
	}
    
}