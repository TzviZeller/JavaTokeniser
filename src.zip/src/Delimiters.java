public interface Delimiters
{
	public boolean isDelimiter(String s);
	public boolean isPairedDelimiter(String s);
	public boolean isLeftDelimiter(String s);
}
