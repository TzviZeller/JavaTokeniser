import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Controller {

	private BufferedReader prog_file;
	private Tokenizer tokenizer;
	private ProgramValidator progValidater;
	ValidatorInterface[] validators;

	public Controller (BufferedReader prog_file, Comments c, Literals l,  Keywords k, Identifiers i, Operators o, Delimiters d, ValidatorInterface[] validators)
	{
		this.prog_file = prog_file;
		LanguageSyntax lang_syntax = new LanguageSyntax(c, l, k,i,o,d);
		tokenizer = new Tokenizer(prog_file, lang_syntax);
		this.validators=validators;

	}

	public void start()
	{
		tokenizer.start();
		// display here for testing only (eventually remove)
		//tokenizer.displayTokenizedLines();
		//tokenizer.displaySymbolTable();

		// validate program
		progValidater = new ProgramValidator(tokenizer.getTokenizedLines(), validators);
		progValidater.start();
		String[] errors = progValidater.getErrors();

		// display results
		displayProgFile(prog_file);
		tokenizer.displaySymbolTable();
		displayErrors(errors);
	}

	private void displayProgFile(BufferedReader prog_file)
	{
		int line_num = 1;
		try {
			prog_file.reset();
		} catch (IOException e) {
		} // reset to first line of file

		// display each line of file with added line number at start of line
	}

	private void displayErrors(String[] errors)
	{
		// displays each of the errorlines in errors
	}


}